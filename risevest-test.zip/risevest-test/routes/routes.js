const express = require('express');
const router = express.Router()
const { profile, userAuth, RegisterUser, LoginUser, checkRole, getUser, getUsers, updateUser, deleteUser } = require('../controllers/usercontroller');
const {Uploads} = require('../controllers/uploadcontroller');
//user
router
.post('/auth/register-user', async (req, res) => {
    await RegisterUser("user", req, res)
});

router
.post('/auth/signin-user', async (req, res) => {
    await LoginUser("user", req, res);
});

//admin
router
.post('/auth/register-admin', async (req, res) => {
    await RegisterUser("admin", req, res)
});

router
.post('/auth/signin-admin', async (request, response) => {
    await LoginUser("admin", request, response);
});

router
.route('/upload/:username')
.post(Uploads)

module.exports = router
//const express = require('express');
//const app = express();
const File = require('../model/Filemodel');
const User = require('../model/Usermodel');
const AWS = require('aws-sdk')
const busboy = require('connect-busboy');
//const multer= require('multer')
//const multerS3=require('multer-s3')
require('dotenv').config();
//app.use(busboy());
//aws.config.setPromisesDependency();
//const s3Uploader = require('@losttracker/s3-uploader');
/*const awsCredentials = {
    secretAccessKey: process.env.AWS_ACCESS_SECRET,
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    region: process.env.AWS_REGION,

};*/
//const s3 = new aws.S3();
//const BUCKET = process.env.AWS_BUCKET

/*const uploadUrlGen = (params) => {
    return params.username + params.filename
}*/

//const maxSize = 200 * 1024 * 1024;

/*const upload = function(filepath) { 
    multer({
    storage: multerS3({
        s3: s3,
        acl: "public-read",
        limit:{
            fileSize: 200 * 1024 * 1024
        },
        contentType: multerS3.AUTO_CONTENT_TYPE,
        bucket: BUCKET,
        key: (req, file, cb) =>{
            cb(null, filepath + '/' + file.originalname)
        }
    })
});
}*/

const uploadToS3Bucket = (image, filePath) => {
    return new Promise((resolve, reject) => {
      let s3 = new AWS.S3({
        secretAccessKey: process.env.AWS_ACCESS_SECRET,
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        region: process.env.AWS_REGION,
      });
  
      const bucketName = process.env.AWS_BUCKET;
  
      let bucketPath = filePath;
  
      let params = {
        Bucket: bucketName,
        Key: bucketPath,
        Body: image,
      };
      s3.putObject(params, function (err, data) {
        if (err) {
          console.log(err);
        } else {
          resolve();
        }
      });
    });
  };



exports.Uploads = async (req, res) => {
        var { folder } = req.body;
       //var fileload = req.file;
    try {
       const user =  await User.findOne({ 
            where: {
                username: `${req.params.username}`
            }
        })
        await File.findOne({
            where: {
                userid: `${user.id}`
            }
        }).then((file)=>{
            if(file){
                if(folder){
                    req.pipe(req.busboy);
                    req.busboy.on('file', async (file, filename) => {
                    const uploadDetails = await uploadToS3Bucket(file,`${user.username}/${folder}/${file}`);;
                    console.log(uploadDetails)
                    filedata = new File({
                        filename: filename,
                        fileurl: uploadDetails.location,
                    })

                    await filedata.save();
                    res.status(200).json(filedata);
                    });
                
                } else{
                    
                    req.pipe(req.busboy);
                    req.busboy.on('file', async (file, filename) => {
                    const uploadDetails = await uploadToS3Bucket(file,`${user.username}/${file}`);;
                    console.log(uploadDetails)
                    filedata = new File({
                        filename: filename,
                        fileurl: uploadDetails.location,
                    })

                    await filedata.save();
                    res.status(200).json(filedata);
                    });
                }
            } else{
                if(folder){
                    
                    req.pipe(req.busboy);
                    req.busboy.on('file', async (file, filename) => {
                    const uploadDetails = await uploadToS3Bucket(file,`${user.username}/${folder}/${file}`);;
                    console.log(uploadDetails)
                    filedata = new File({
                        userid: user.id,
                        filename: filename,
                        fileurl: uploadDetails.location,
                    })

                    await filedata.save();
                    res.status(200).json(filedata);
                    });
                } else{
                    
                    req.pipe(req.busboy);
                    req.busboy.on('file', async (file, filename) => {
                    const data = await uploadToS3Bucket(req.file,`${user.username}/${file}`)
                    
                        console.log(data)
                        filedata = new File({
                            userid: user.id,
                            filename: filename,
                            fileurl: data.location,
                        })

                    await filedata.save();
                    res.status(200).json(filedata);
                    

                    });
                }
            }
        })
        
    } catch (error) {
        console.log(req.file)
        console.log(error);
        res.status(500).json({
            status: false,
            message: error
        })
    };
};


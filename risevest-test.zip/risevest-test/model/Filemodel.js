const Sequelize = require('sequelize');
const db = require('../configs/config');
const user = require('./Usermodel');

const File = db.define('File', {
    userid: {
        type: Sequelize.INTEGER,
        references:{ 
            model: 'Users',
            key: 'id',
        }
    },
    filename: {
        type: Sequelize.STRING
    },
    fileurl: {
        type: Sequelize.STRING
    },
});

user.hasMany(File, {foreignKey: 'userid'});

module.exports = File;
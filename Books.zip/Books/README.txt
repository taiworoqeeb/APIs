Hello,

1. To run the project make sure you are in the server dir i.e C:\[user dir]\Books\server
2. Use "npm run dev" to run the server with nodemon and "npm start" to run it with node.
3. For your Database, you set your Mongodb cloud database url in the ".env" file by replacing the url in front of "DATABASE" with your own.
4. You can test with postman
5. The route for books is localhost:3000/api/book
6. The route for author is localhost:3000/api/author

if you need any other thing let me know.
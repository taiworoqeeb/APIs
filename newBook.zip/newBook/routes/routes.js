const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const bookController = require('../controllers/bookController');
const authorController = require('../controllers/authorController');
const genreController = require('../controllers/genreController');
const reviewController = require('../controllers/reviewController');

router
.route('/signup/')
.post(userController.signup);

router
.route('/login/')
.post(userController.login);

router
.route('/users/:Id')
.get(userController.getUser)
.patch(userController.updateUser)
.delete(userController.deleteUser);

router
.route('/users/')
.get(userController.getUsers);

router
.route('/books/:id')
.get(bookController.GetBook)
.patch(bookController.UpdateBook)
.delete(bookController.DeleteBook);

router
.route('/books/')
.post(bookController.CreateBook)
.get(bookController.GetAllBooks); //books/index

router
.route('/authors/:id')
.get(authorController.GetAuthor)
.patch(authorController.UpdateAuthor)
.delete(authorController.DeleteAuthor);

router
.route('/authors/')
.post(authorController.CreateAuthor)
.get(authorController.GetAllAuthors);

router
.route('/genres/:id')
.get(genreController.Getgenre)
.patch(genreController.Updategenre)
.delete(genreController.Deletegenre);

router
.route('/genres/')
.post(genreController.Creategenre)
.get(genreController.GetAllgenres);


router
.route('/reviews/:id')
.get(reviewController.Getreview)
.patch(reviewController.Updatereview)
.delete(reviewController.Deletereview);

router
.route('/reviews/')
.post(reviewController.Createreview)
.get(reviewController.GetAllreviews);

//For search only
router
.route('/books/search/')
.get(bookController.searchBook)

module.exports = router;